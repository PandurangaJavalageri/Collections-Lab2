﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionAndGenericLab2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<string> list = CreateAndPopulateList();
            DisplayListContents(list);
            InsertName("hi", list, 0);
            Console.WriteLine();
            Console.WriteLine(list[0]);
        }
        public static List<string> CreateAndPopulateList()
        {
            List<string> list=new List<string>();
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("enter name");
                list.Add(Console.ReadLine());
            }
            return list;
        }
        public static void DisplayListContents(List<string> list)
        {
            foreach (string item in list)
            {
                Console.WriteLine(item);
            }
        }
        public static void InsertName(string name,List<string>L,int ind)
        {
            L.Insert(ind, name);
        }
    }
}
