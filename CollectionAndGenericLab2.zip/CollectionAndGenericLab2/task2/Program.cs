﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Dictionary<int,string >dic = CreatePopulateDictionary();
            findNameById(dic,2);
            update(dic, 3);
            Console.WriteLine(dic[3]);


        }

        public static Dictionary<int, string> CreatePopulateDictionary()
        {
            Dictionary<int, string> dict = new Dictionary<int, string>();
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("enter  id");
                int id = int.Parse(Console.ReadLine());
                Console.WriteLine("enter name");
                string name = Console.ReadLine();
                dict.Add(id, name);
            }
            return dict;
        }
        public static void findNameById(Dictionary<int,string>d,int id)
        {
            if(d.ContainsKey(id))
            Console.WriteLine(d[id]);
            else
            {
                Console.WriteLine("id not found");
            }
        }
        public static void update(Dictionary<int,string>d,int id)
        {
            Console.WriteLine("enter name");
            string name = Console.ReadLine();
            d[id]= name;
        }


    }
}
