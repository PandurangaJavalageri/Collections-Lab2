﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Queue<string> queue = new Queue<string>();
            queue.Enqueue("A");
            queue.Enqueue("B");
            queue.Enqueue("C");
            queue.Enqueue("D");
            queue.Enqueue("E");
            Stack<string> stack = new Stack<string>();
            stack.Push("A");
            stack.Push("B");
            stack.Push("C");
            stack.Push("D");
            stack.Push("E");
            plusQueue("z",queue);
            minusQueue(queue);
            plusStack("y", stack);
            minusStack(stack);
            iterate(queue,stack);

        }
        public static void plusQueue(string s,Queue<string>q)
        {
            q.Enqueue(s);
        }
        public static void minusQueue(Queue<string>q)
        {
            Console.WriteLine(q.Dequeue());
            
        }
        public static void plusStack(string k,Stack<string>s) 
        { 
            s.Push(k);
        }
        public static void minusStack(Stack<string>s) 
        {
            Console.WriteLine(s.Pop());
        }
        public static void iterate(Queue<string>q,Stack<string>s) 
        {
            Console.WriteLine("stack iteration");
            foreach(var i in s)
            {
                Console.WriteLine(i);
            }
            Console.WriteLine();
            Console.WriteLine();
            foreach (var i in q)
            {
                Console.WriteLine(i);
            }
        }
    }
}
